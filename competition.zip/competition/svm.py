import pandas as pd
import csv
from sklearn import svm, metrics

print("Read train input")
traininput = pd.read_csv('train.csv', sep=',')
traininput = traininput.drop('Prediction', axis=1)
	
print("Read train output")
trainoutput = pd.read_csv('train.csv', sep=',',usecols=['Prediction'])

print("Read test input")
testinput = pd.read_csv('test.csv', sep=',')
testinput = testinput.drop('Prediction', axis=1)

svc = svm.SVC(C=100000, gamma=0.000001)
print(svc)
print("SVC Fit data")
svc.fit(traininput.values, trainoutput.values.ravel())
print("SVC Predict data")
predicted = svc.predict(testinput.values)

h = 1+len(traininput.values)+len(testinput.values)
w = 2
result = [[0 for x in range(w)] for y in range(h)]
result[0][0] = 'Id'
result[0][1] = 'Prediction'
for i in range(len(traininput.values)):
	result[1+i][0] = traininput.values[i][0]
	result[1+i][1] = trainoutput.values[i][0]

for i in range(len(testinput.values)):
	result[1+len(traininput.values)+i][0] = testinput.values[i][0]
	result[1+len(traininput.values)+i][1] = predicted[i]

out = open("aSubmission.csv", 'wb')
wr = csv.writer(out)
wr.writerows(result)

score = svc.score(traininput.values, trainoutput.values.ravel())
print(score)
